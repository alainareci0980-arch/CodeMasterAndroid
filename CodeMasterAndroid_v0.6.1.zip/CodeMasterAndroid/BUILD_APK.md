# Cómo obtener CodeMaster-0.6.1-debug.apk

## Opción A: GitHub Actions (recomendada desde el teléfono)

1. Sube el contenido de esta carpeta al repositorio `CodeMasterAndroid`, en la rama `main` o `master`.
2. Abre la pestaña **Actions** del repositorio.
3. Selecciona **Build CodeMaster APK** y pulsa **Run workflow** (o espera a que termine la ejecución automática después de subir los cambios).
4. Abre la ejecución cuando aparezca con un indicador verde.
5. En **Artifacts**, descarga `CodeMaster-0.6.1-debug-apk`.
6. Descomprime el artefacto y encontrarás `app-debug.apk`.

## Opción B: Android Studio

Requisitos: Android Studio, JDK 17, Android SDK Platform 35 y Gradle 8.9.

1. Abre la carpeta del proyecto `CodeMasterAndroid`.
2. Espera a que finalice la sincronización de Gradle.
3. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. El archivo se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Importante

Este paquete contiene el código fuente Android, no un APK ya compilado. La compilación debe ejecutarse en Android Studio o GitHub Actions, donde sí están disponibles Gradle y Android SDK.
