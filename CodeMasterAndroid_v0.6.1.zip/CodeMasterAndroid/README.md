# CodeMaster Android — versión 0.6.1

CodeMaster es una aplicación Android nativa escrita en Kotlin para editar código y crear recursos de Minecraft Bedrock.

## Funciones incluidas

- Editor con hasta 10 pestañas, resaltado básico, búsqueda y reemplazo, deshacer/rehacer, formato JSON, salto a línea y tamaño de letra.
- Abrir y guardar archivos mediante el selector seguro de Android (SAF).
- Explorador de carpetas autorizadas por el usuario, con creación de archivos y subcarpetas.
- Vista de imágenes y listado del contenido de ZIP, MCADDON, MCPACK y APK.
- Minecraft Bedrock Studio: exportación de paquetes `.mcpack` y `.mcaddon`, geometría cúbica `.geo.json`, importación de texturas PNG y plantillas JSON.
- Laboratorio de mods y herramientas experimentales locales.

## Requisitos

- Android Studio compatible con Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35.
- Gradle 8.9.
- Android 6.0 (API 23) o posterior para instalar la aplicación.

## Generar el APK desde Android Studio

1. Descomprime este proyecto.
2. En Android Studio, elige **Open** y selecciona la carpeta `CodeMasterAndroid`.
3. Espera a que Gradle sincronice el proyecto.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. El APK de depuración estará en `app/build/outputs/apk/debug/app-debug.apk`.

## Generar el APK con GitHub Actions

1. Sube el contenido de esta carpeta a la rama `main` o `master` de tu repositorio.
2. En GitHub abre **Actions** y selecciona **Build CodeMaster APK**.
3. Pulsa **Run workflow** si no se inició automáticamente.
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto `CodeMaster-0.6.1-debug-apk`.
5. Dentro del artefacto estará `app-debug.apk`, listo para instalar en un dispositivo Android compatible.

El flujo instala JDK 17, Android SDK 35 y Gradle 8.9, compila el proyecto y verifica que el APK exista antes de publicarlo como artefacto.

## Notas importantes

- La variante `debug` usa el identificador `com.codemaster.android.debug`, para poder instalarla junto a una futura versión de producción.
- El constructor 3D actual genera geometría cúbica básica y una previsualización isométrica 2D; todavía no es un editor de mallas libre ni un visor 3D de rotación libre.
- La app solo puede acceder a los archivos y carpetas que el usuario selecciona y autoriza mediante Android.
- No se ha generado ni probado un APK en este entorno: aquí no están instalados Gradle ni Android SDK y no hay acceso de red para descargarlos. La compilación verificable se realiza con Android Studio o GitHub Actions.
