package com.codemaster.android

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.app.AlertDialog
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.text.Spannable
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.text.InputType
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.util.UUID

class MainActivity : ComponentActivity() {
    private lateinit var fileName: TextView
    private lateinit var editor: CodeEditText
    private lateinit var tabsContainer: LinearLayout
    private lateinit var cursorInfo: TextView
    private lateinit var preview: LinearLayout
    private lateinit var editorPanel: LinearLayout
    private lateinit var previewPanel: ScrollView
    private lateinit var folderPanel: LinearLayout
    private lateinit var minecraftPanel: LinearLayout
    private lateinit var gameLabPanel: LinearLayout
    private lateinit var infinityPanel: LinearLayout
    private lateinit var minecraftScroll: ScrollView
    private lateinit var gameLabScroll: ScrollView
    private lateinit var infinityScroll: ScrollView
    private lateinit var infinityReport: TextView
    private lateinit var packNameInput: EditText
    private lateinit var packDescriptionInput: EditText
    private lateinit var packTypeSpinner: Spinner
    private lateinit var geometryIdentifierInput: EditText
    private lateinit var geometrySizeXInput: EditText
    private lateinit var geometrySizeYInput: EditText
    private lateinit var geometrySizeZInput: EditText
    private lateinit var textureWidthInput: EditText
    private lateinit var textureHeightInput: EditText
    private lateinit var geometryPreview: TextView
    private lateinit var textureInfo: TextView
    private lateinit var texturePreview: ImageView
    private lateinit var modelPreview: ModelPreviewView
    private lateinit var blockIdentifierInput: EditText
    private lateinit var entityIdentifierInput: EditText
    private lateinit var status: TextView
    private var currentUri: Uri? = null
    private var currentName = ""
    private var currentMime = ""
    private var currentBytes: ByteArray? = null
    private var importedTextureBytes: ByteArray? = null
    private var importedTextureName: String = ""
    private var folderUri: Uri? = null
    private val folderStack = mutableListOf<Pair<String, String>>()
    private var applyingHighlight = false
    private var loadingDocument = false
    private var applyingHistory = false
    private var previousText = ""
    private var isDirty = false
    private var textEditable = false
    private var editorFontSize = 13f
    private val openDocuments = mutableListOf<EditorDocument>()
    private var activeDocumentKey: String? = null
    private val undoHistory = java.util.ArrayDeque<String>()
    private val redoHistory = java.util.ArrayDeque<String>()
    private var pendingSaveAsBytes: ByteArray = byteArrayOf()
    private var pendingDemoBytes: ByteArray = byteArrayOf()
    private var pendingGeometryBytes: ByteArray = byteArrayOf()
    private var generatedGeometryJson: String? = null
    private var pendingAddonEntries: LinkedHashMap<String, ByteArray> = linkedMapOf()

    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadDocument(uri)
    }
    private val createFile = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) saveTo(uri)
    }
    private val createDemoFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(pendingDemoBytes) }
                status.text = "Plantilla JSON exportada"
                Toast.makeText(this, "JSON exportado", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "No se pudo exportar: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
    private val createGeometryFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(pendingGeometryBytes) }
                status.text = "Geometría Bedrock exportada · .geo.json"
                Toast.makeText(this, "Modelo JSON exportado", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "No se pudo exportar: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
    private val createAddonFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { output ->
                    ZipOutputStream(output).use { zip ->
                        pendingAddonEntries.forEach { (entryName, bytes) ->
                            zip.putNextEntry(java.util.zip.ZipEntry(entryName))
                            zip.write(bytes)
                            zip.closeEntry()
                        }
                    }
                }
                status.text = "Complemento .mcaddon exportado con paquetes de comportamiento y recursos"
                Toast.makeText(this, "MCADDON exportado", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "No se pudo exportar: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
    private val openFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) { }
            folderUri = uri
            folderStack.clear()
            folderStack.add(DocumentsContract.getTreeDocumentId(uri) to "Raíz")
            showFolderContents(uri)
            showPanel("folder")
        }
    }

    private data class EditorDocument(
        var key: String,
        var uri: Uri?,
        var name: String,
        var mime: String,
        var text: String,
        var bytes: ByteArray?,
        var dirty: Boolean = false
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
    }

    private fun buildInterface() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 20, 16, 12)
            setBackgroundColor(0xFFF2F5FA.toInt())
        }
        page.addView(TextView(this).apply {
            text = "CodeMaster"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF17233B.toInt())
        })
        page.addView(TextView(this).apply {
            text = "Editor avanzado · versión 0.6.1"; textSize = 14f
            setTextColor(0xFF596579.toInt())
        })
        fileName = TextView(this).apply {
            text = "Ningún archivo abierto"; textSize = 13f
            setPadding(0, 12, 0, 8); setTextColor(0xFF315DAB.toInt())
        }
        page.addView(fileName)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("Abrir") { openFile.launch(arrayOf("*/*")) }, weightParams())
        actions.addView(actionButton("Carpeta") { openFolder.launch(null) }, weightParams())
        actions.addView(actionButton("Nuevo") { newBlankDocument() }, weightParams())
        actions.addView(actionButton("Guardar copia") { saveCurrentAs() }, weightParams())
        page.addView(actions)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
        nav.addView(actionButton("Código") { showPanel("editor") }, weightParams())
        nav.addView(actionButton("Visual") { refreshPreview(); showPanel("preview") }, weightParams())
        nav.addView(actionButton("Archivos") { folderUri?.let { showFolderContents(it) }; showPanel("folder") }, weightParams())
        page.addView(nav)

        val featureNav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        featureNav.addView(actionButton("Crear mod MC") { showPanel("minecraft") }, weightParams())
        featureNav.addView(actionButton("Laboratorio") { showPanel("gamelab") }, weightParams())
        featureNav.addView(actionButton("Infinity Lab") { showPanel("infinity") }, weightParams())
        page.addView(featureNav)

        editor = CodeEditText(this).apply {
            hint = "Crea un archivo nuevo o abre uno existente…"
            textSize = editorFontSize; typeface = Typeface.MONOSPACE
            gravity = Gravity.TOP or Gravity.START
            setPadding(12, 12, 12, 12); setBackgroundColor(0xFFFFFFFF.toInt())
            minLines = 12
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setHorizontallyScrolling(true)
        }
        editor.selectionChanged = { updateCursorInfo() }
        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                previousText = s?.toString() ?: ""
            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val updated = s?.toString() ?: ""
                if (!loadingDocument && !applyingHistory && updated != previousText) {
                    if (previousText.length <= 250_000) {
                        undoHistory.addLast(previousText)
                        while (undoHistory.size > 60 || undoHistory.sumOf { it.length } > 1_000_000) undoHistory.removeFirst()
                    } else {
                        undoHistory.clear()
                    }
                    redoHistory.clear()
                    val firstUnsavedChange = !isDirty
                    isDirty = true
                    storeActiveDocument()
                    updateFileHeader()
                    if (firstUnsavedChange) renderTabs()
                }
                if (!applyingHighlight) highlightCode(s)
                updateCursorInfo()
            }
        })
        val tabsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = true
            addView(LinearLayout(this@MainActivity).also { tabsContainer = it; it.orientation = LinearLayout.HORIZONTAL })
        }
        val toolsFirst = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toolsFirst.addView(actionButton("Guardar") { saveCurrent() }, weightParams())
        toolsFirst.addView(actionButton("Deshacer") { undoEdit() }, weightParams())
        toolsFirst.addView(actionButton("Rehacer") { redoEdit() }, weightParams())
        toolsFirst.addView(actionButton("Buscar") { showSearchReplaceDialog() }, weightParams())
        val toolsSecond = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toolsSecond.addView(actionButton("JSON bonito") { formatCurrentJson() }, weightParams())
        toolsSecond.addView(actionButton("Ir a línea") { showGoToLineDialog() }, weightParams())
        toolsSecond.addView(actionButton("A−") { changeEditorFont(-1f) }, weightParams())
        toolsSecond.addView(actionButton("A+") { changeEditorFont(1f) }, weightParams())
        cursorInfo = infoText("Línea 1 · Columna 1 · 0 caracteres")
        editorPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tabsScroll, LinearLayout.LayoutParams(-1, -2))
            addView(toolsFirst, LinearLayout.LayoutParams(-1, -2))
            addView(toolsSecond, LinearLayout.LayoutParams(-1, -2))
            addView(cursorInfo, LinearLayout.LayoutParams(-1, -2))
            addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        preview = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12) }
        previewPanel = ScrollView(this).apply { addView(preview) }
        folderPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8) }
        minecraftPanel = buildMinecraftStudio()
        gameLabPanel = buildGameLab()
        infinityPanel = buildInfinityLab()
        val content = FrameLayoutCompat(this)
        content.addView(editorPanel)
        content.addView(previewPanel)
        content.addView(folderPanel)
        minecraftScroll = ScrollView(this).apply { addView(minecraftPanel) }
        gameLabScroll = ScrollView(this).apply { addView(gameLabPanel) }
        infinityScroll = ScrollView(this).apply { addView(infinityPanel) }
        content.addView(minecraftScroll)
        content.addView(gameLabScroll)
        content.addView(infinityScroll)
        page.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this).apply {
            text = "Trabaja sobre copias. Solo puedes abrir archivos y carpetas que Android te permita seleccionar."
            textSize = 11f; setTextColor(0xFF596579.toInt()); setPadding(0, 8, 0, 0)
        }
        page.addView(status)
        setContentView(page)
        showPanel("editor")
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; setOnClickListener { action() }
    }
    private fun weightParams() = LinearLayout.LayoutParams(0, -2, 1f)

    private fun showPanel(which: String) {
        editorPanel.visibility = if (which == "editor") View.VISIBLE else View.GONE
        previewPanel.visibility = if (which == "preview") View.VISIBLE else View.GONE
        folderPanel.visibility = if (which == "folder") View.VISIBLE else View.GONE
        minecraftScroll.visibility = if (which == "minecraft") View.VISIBLE else View.GONE
        gameLabScroll.visibility = if (which == "gamelab") View.VISIBLE else View.GONE
        infinityScroll.visibility = if (which == "infinity") View.VISIBLE else View.GONE
    }

    private fun buildMinecraftStudio(): LinearLayout {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12) }
        panel.addView(infoText("ESTUDIO DE ADDONS · MINECRAFT BEDROCK"))
        panel.addView(infoText("Genera paquetes y recursos base para proyectos Bedrock. Las funciones experimentales de Minecraft pueden cambiar según la versión del juego."))
        packNameInput = EditText(this).apply { hint = "Nombre del addon"; setSingleLine(true) }
        packDescriptionInput = EditText(this).apply { hint = "Descripción del addon"; setText("Addon creado con CodeMaster") }
        packTypeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Paquete de comportamiento", "Paquete de recursos"))
        }
        panel.addView(infoText("PAQUETES"))
        panel.addView(infoText("1. Nombre del paquete")); panel.addView(packNameInput)
        panel.addView(infoText("2. Descripción")); panel.addView(packDescriptionInput)
        panel.addView(infoText("3. Tipo de paquete .mcpack")); panel.addView(packTypeSpinner)
        panel.addView(actionButton("Exportar paquete .mcpack") { exportMinecraftPack() })
        panel.addView(actionButton("Exportar addon doble .mcaddon") { exportMinecraftAddon() })

        panel.addView(infoText("CONSTRUCTOR DE MODELOS · GEOMETRÍA BEDROCK"))
        panel.addView(infoText("Crea un modelo cúbico con dimensiones editables, vista isométrica y exportación .geo.json. La vista previa es una representación visual del cubo, no un editor de malla libre."))
        geometryIdentifierInput = EditText(this).apply {
            setText("geometry.codemaster.cube"); hint = "Identificador de geometría"; setSingleLine(true)
        }
        panel.addView(infoText("Identificador")); panel.addView(geometryIdentifierInput)
        val dimensions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        geometrySizeXInput = numericInput("X", "1")
        geometrySizeYInput = numericInput("Y", "1")
        geometrySizeZInput = numericInput("Z", "1")
        dimensions.addView(geometrySizeXInput, weightParams())
        dimensions.addView(geometrySizeYInput, weightParams())
        dimensions.addView(geometrySizeZInput, weightParams())
        panel.addView(infoText("Tamaño del cubo (unidades Bedrock, máximo 32 por eje)"))
        panel.addView(dimensions)
        val previewWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val x = geometrySizeXInput.text.toString().replace(',', '.').toFloatOrNull() ?: 1f
                val y = geometrySizeYInput.text.toString().replace(',', '.').toFloatOrNull() ?: 1f
                val z = geometrySizeZInput.text.toString().replace(',', '.').toFloatOrNull() ?: 1f
                modelPreview.setDimensions(x, y, z)
            }
            override fun afterTextChanged(s: Editable?) {}
        }
        geometrySizeXInput.addTextChangedListener(previewWatcher)
        geometrySizeYInput.addTextChangedListener(previewWatcher)
        geometrySizeZInput.addTextChangedListener(previewWatcher)
        val textureDimensions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        textureWidthInput = numericInput("Ancho UV", "64")
        textureHeightInput = numericInput("Alto UV", "64")
        textureDimensions.addView(textureWidthInput, weightParams())
        textureDimensions.addView(textureHeightInput, weightParams())
        panel.addView(infoText("Tamaño de la textura")); panel.addView(textureDimensions)
        modelPreview = ModelPreviewView(this)
        panel.addView(modelPreview, LinearLayout.LayoutParams(-1, dp(170)))
        geometryPreview = infoText("La geometría generada aparecerá aquí.", true)
        panel.addView(geometryPreview)
        panel.addView(actionButton("Generar y exportar modelo .geo.json") { generateGeometry() })
        panel.addView(actionButton("Importar textura PNG") { openFile.launch(arrayOf("image/png")) })
        textureInfo = infoText("Todavía no has importado una textura.")
        panel.addView(textureInfo)
        texturePreview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFFE8EEF7.toInt())
        }
        panel.addView(texturePreview, LinearLayout.LayoutParams(-1, dp(150)))

        panel.addView(infoText("GENERADORES DE PLANTILLAS"))
        blockIdentifierInput = EditText(this).apply { setText("codemaster:example_block"); hint = "Identificador del bloque"; setSingleLine(true) }
        entityIdentifierInput = EditText(this).apply { setText("codemaster:example_entity"); hint = "Identificador de la entidad"; setSingleLine(true) }
        panel.addView(infoText("Identificador de bloque")); panel.addView(blockIdentifierInput)
        panel.addView(actionButton("Crear plantilla de bloque JSON") { exportBlockTemplate() })
        panel.addView(infoText("Identificador de entidad")); panel.addView(entityIdentifierInput)
        panel.addView(actionButton("Crear plantilla de entidad JSON") { exportEntityTemplate() })

        panel.addView(infoText("GUÍA RÁPIDA"))
        panel.addView(infoText(
            "1) Crea una geometría y guarda el archivo .geo.json.\n" +
            "2) Coloca el modelo en models/entity/ dentro de un paquete de recursos.\n" +
            "3) Coloca la textura PNG en textures/entity/ y ajusta el tamaño UV al de tu imagen.\n" +
            "4) Enlaza el identificador geometry.codemaster... y la textura desde la definición cliente de la entidad.\n" +
            "5) Usa las plantillas de bloque y entidad como punto de partida; después añade identificadores, componentes y recursos compatibles.\n" +
            "6) Exporta un .mcpack o un .mcaddon y pruébalo en un mundo de copia.\n\n" +
            "Nota: esta versión genera un cubo geométrico básico y plantillas JSON. Aún no dispone de esculpido libre, rigging, animaciones ni pincel de píxeles."
        ))
        return panel
    }

    private fun numericInput(label: String, value: String): EditText = EditText(this).apply {
        hint = label; setText(value); setSingleLine(true)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun generateGeometry() {
        try {
            val identifier = geometryIdentifierInput.text.toString().trim()
            require(identifier.matches(Regex("geometry\\.[a-z0-9_.-]+"))) {
                "Usa un identificador como geometry.codemaster.cube (sin espacios)."
            }
            fun readDimension(field: EditText, label: String): Float {
                val number = field.text.toString().trim().replace(',', '.').toFloatOrNull()
                    ?: throw IllegalArgumentException("$label debe ser un número.")
                require(number > 0f && number <= 32f) { "$label debe estar entre 0 y 32." }
                return number
            }
            fun readTextureDimension(field: EditText, label: String): Int {
                val number = field.text.toString().trim().toIntOrNull()
                    ?: throw IllegalArgumentException("$label debe ser un entero.")
                require(number in 1..4096) { "$label debe estar entre 1 y 4096." }
                return number
            }
            val x = readDimension(geometrySizeXInput, "X")
            val y = readDimension(geometrySizeYInput, "Y")
            val z = readDimension(geometrySizeZInput, "Z")
            val textureWidth = readTextureDimension(textureWidthInput, "Ancho UV")
            val textureHeight = readTextureDimension(textureHeightInput, "Alto UV")
            val cube = JSONObject().apply {
                put("origin", JSONArray().put(-x / 2f).put(0).put(-z / 2f))
                put("size", JSONArray().put(x).put(y).put(z))
                put("uv", JSONArray().put(0).put(0))
            }
            val geometry = JSONObject().apply {
                put("format_version", "1.12.0")
                put("minecraft:geometry", JSONArray().put(JSONObject().apply {
                    put("description", JSONObject().apply {
                        put("identifier", identifier)
                        put("texture_width", textureWidth)
                        put("texture_height", textureHeight)
                        put("visible_bounds_width", maxOf(x, z, 2f) + 1f)
                        put("visible_bounds_height", maxOf(y, 2f) + 1f)
                        put("visible_bounds_offset", JSONArray().put(0).put(y / 2f).put(0))
                    })
                    put("bones", JSONArray().put(JSONObject().apply {
                        put("name", "root")
                        put("pivot", JSONArray().put(0).put(0).put(0))
                        put("cubes", JSONArray().put(cube))
                    }))
                }))
            }
            generatedGeometryJson = geometry.toString(2)
            pendingGeometryBytes = generatedGeometryJson!!.toByteArray(Charsets.UTF_8)
            geometryPreview.text = generatedGeometryJson
            val safeId = identifier.substringAfter(':').replace(Regex("[^A-Za-z0-9_.-]"), "_")
            status.text = "Geometría generada · ${x}×${y}×${z} · lista para exportar"
            createGeometryFile.launch("$safeId.geo.json")
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "No se pudo generar el modelo", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportBlockTemplate() {
        val identifier = blockIdentifierInput.text.toString().trim()
        if (!identifier.matches(Regex("[a-z0-9_.-]+:[a-z0-9_./-]+"))) {
            Toast.makeText(this, "Usa un identificador como codemaster:example_block", Toast.LENGTH_LONG).show(); return
        }
        val block = JSONObject().apply {
            put("format_version", "1.21.0")
            put("minecraft:block", JSONObject().apply {
                put("description", JSONObject().apply {
                    put("identifier", identifier)
                    put("menu_category", JSONObject().put("category", "construction"))
                })
                put("components", JSONObject().apply {
                    put("minecraft:destructible_by_mining", JSONObject().put("seconds_to_destroy", 1.5))
                    put("minecraft:collision_box", true)
                    put("minecraft:selection_box", true)
                })
            })
        }
        pendingDemoBytes = block.toString(2).toByteArray(Charsets.UTF_8)
        createDemoFile.launch(identifier.substringAfter(':') + ".block.json")
    }

    private fun exportEntityTemplate() {
        val identifier = entityIdentifierInput.text.toString().trim()
        if (!identifier.matches(Regex("[a-z0-9_.-]+:[a-z0-9_./-]+"))) {
            Toast.makeText(this, "Usa un identificador como codemaster:example_entity", Toast.LENGTH_LONG).show(); return
        }
        val entity = JSONObject().apply {
            put("format_version", "1.20.0")
            put("minecraft:entity", JSONObject().apply {
                put("description", JSONObject().apply {
                    put("identifier", identifier)
                    put("is_spawnable", true)
                    put("is_summonable", true)
                    put("is_experimental", false)
                })
                put("components", JSONObject().apply {
                    put("minecraft:type_family", JSONObject().put("family", JSONArray().put("codemaster").put("mob")))
                    put("minecraft:health", JSONObject().put("value", 20).put("max", 20))
                    put("minecraft:movement", JSONObject().put("value", 0.25))
                    put("minecraft:collision_box", JSONObject().put("width", 0.6).put("height", 1.8))
                    put("minecraft:physics", JSONObject())
                })
            })
        }
        pendingDemoBytes = entity.toString(2).toByteArray(Charsets.UTF_8)
        createDemoFile.launch(identifier.substringAfter(':') + ".entity.json")
    }

    private fun buildGameLab(): LinearLayout {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12) }
        panel.addView(infoText("LABORATORIO DE MODS DE JUEGOS"))
        panel.addView(infoText("Esta sección es independiente del creador de Minecraft. Sirve para organizar y probar modificaciones en juegos que admiten mods, proyectos propios o entornos locales autorizados."))
        panel.addView(actionButton("Abrir archivo de mod o proyecto") { openFile.launch(arrayOf("*/*")) })
        panel.addView(actionButton("Elegir carpeta del proyecto") { openFolder.launch(null) })
        panel.addView(infoText("""
            Flujo recomendado:
            1) Haz una copia del proyecto original.
            2) Comprueba que el juego permita mods y revisa sus formatos admitidos.
            3) Edita recursos o configuraciones documentadas.
            4) Prueba primero sin conexión o en un entorno privado de pruebas.
            5) Exporta la copia modificada y conserva el original.

            Los cambios de monedas o progreso se limitan a juegos propios, modos locales o herramientas de prueba autorizadas. CodeMaster no modifica saldos de servidores, compras, cuentas ni datos privados de otras aplicaciones.
        """.trimIndent()))
        return panel
    }


    private fun buildInfinityLab(): LinearLayout {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }
        panel.addView(infoText("INFINITY LAB · MODO EXPERIMENTAL"))
        panel.addView(infoText(
            "Laboratorio independiente para simular monedas y probar sistemas de recompensas " +
            "en juegos propios, prototipos y proyectos que permitan modificaciones."
        ))
        panel.addView(infoText("1. Analizador de datos"))
        panel.addView(actionButton("Analizar archivo abierto") { analyzeCurrentFile() })
        infinityReport = infoText(
            "Abre un archivo de tu proyecto y pulsa Analizar. El análisis es estático: " +
            "no accede a datos privados de otras aplicaciones ni confirma saldos reales."
        )
        panel.addView(infinityReport)
        panel.addView(infoText("2. Simulador de monedas"))
        panel.addView(infoText(
            "Genera un archivo JSON de ejemplo con una billetera ficticia. Úsalo como plantilla " +
            "en un proyecto propio; no cambia monedas de juegos instalados ni saldos en servidores."
        ))
        panel.addView(actionButton("Crear archivo de billetera de prueba") {
            val demo = JSONObject().apply {
                put("schema", "codemaster.infinity-lab.demo.v1")
                put("notice", "DEMO ONLY — no representa compras ni saldo real")
                put("project", "Mi juego de prueba")
                put("wallet", JSONObject().apply {
                    put("coins", 999999)
                    put("gems", 999999)
                    put("editable_in_local_test", true)
                })
                put("server_authority", "not_connected")
            }
            pendingDemoBytes = demo.toString(2).toByteArray(Charsets.UTF_8)
            createDemoFile.launch("codemaster_billetera_demo.json")
        })
        panel.addView(infoText("3. Límites y uso responsable"))
        panel.addView(infoText(
            "• Puede revisar texto/JSON que tú abras mediante el selector de Android.\n" +
            "• Puede señalar palabras como coins, gems, wallet, balance o purchase para ayudarte " +
            "a localizar configuraciones de un proyecto.\n" +
            "• Una coincidencia no demuestra que el saldo sea local ni que pueda editarse.\n" +
            "• No falsifica recibos, compras, autenticación ni respuestas de servidores.\n" +
            "• No intenta acceder al almacenamiento privado de otras aplicaciones.\n" +
            "• Conserva el original y exporta siempre una copia."
        ))
        return panel
    }

    private fun analyzeCurrentFile() {
        val source = editor.text.toString()
        if (currentUri == null || source.isBlank()) {
            infinityReport.text = "No hay un archivo de texto abierto. Abre un JSON, XML o archivo de configuración de un proyecto propio."
            return
        }
        val terms = listOf("coins", "coin", "gems", "opal", "wallet", "balance", "currency", "purchase", "receipt", "server", "sync")
        val found = terms.filter { term ->
            Regex("(?i)\\b" + Regex.escape(term) + "\\b").containsMatchIn(source)
        }
        val lines = source.lines()
        val matches = lines.mapIndexedNotNull { index, line ->
            if (terms.any { term -> Regex("(?i)\\b" + Regex.escape(term) + "\\b").containsMatchIn(line) }) {
                "${index + 1}: ${line.trim().take(140)}"
            } else null
        }.take(12)
        val report = buildString {
            append("Archivo: ").append(currentName).append("\n")
            append("Términos encontrados: ")
            append(if (found.isEmpty()) "ninguno" else found.joinToString(", "))
            append("\n\n")
            if (matches.isEmpty()) {
                append("No se encontraron referencias evidentes a monedas o sincronización.")
            } else {
                append("Líneas candidatas (máximo 12):\n")
                append(matches.joinToString("\n"))
            }
            append("\n\nConclusión: esto solo localiza texto en el archivo seleccionado. ")
            append("No determina dónde se valida el saldo ni permite cambiar monedas de una cuenta.")
        }
        infinityReport.text = report
        status.text = "Análisis estático terminado · sin modificar el archivo"
    }

    private fun createManifest(name: String, description: String, moduleType: String, headerUuid: String = UUID.randomUUID().toString()): JSONObject {
        return JSONObject().apply {
            put("format_version", 2)
            put("header", JSONObject().apply {
                put("name", name)
                put("description", description)
                put("uuid", headerUuid)
                put("version", JSONArray().put(1).put(0).put(0))
                put("min_engine_version", JSONArray().put(1).put(20).put(0))
            })
            put("modules", JSONArray().put(JSONObject().apply {
                put("type", moduleType)
                put("uuid", UUID.randomUUID().toString())
                put("version", JSONArray().put(1).put(0).put(0))
            }))
        }
    }

    private fun exportMinecraftPack() {
        val name = packNameInput.text.toString().trim().ifBlank { "MiAddon" }
        val description = packDescriptionInput.text.toString().trim().ifBlank { "Addon creado con CodeMaster" }
        val isResource = packTypeSpinner.selectedItemPosition == 1
        val moduleType = if (isResource) "resources" else "data"
        val manifest = createManifest(name, description, moduleType)
        pendingManifestBytes = manifest.toString(2).toByteArray(Charsets.UTF_8)
        pendingPackFileName = name.replace(Regex("[^A-Za-z0-9_-]"), "_") + if (isResource) "_recursos.mcpack" else "_comportamiento.mcpack"
        createPackFile.launch(pendingPackFileName)
    }

    private fun exportMinecraftAddon() {
        val name = packNameInput.text.toString().trim().ifBlank { "CodeMasterAddon" }
        val description = packDescriptionInput.text.toString().trim().ifBlank { "Addon creado con CodeMaster" }
        val bpHeader = UUID.randomUUID().toString()
        val rpHeader = UUID.randomUUID().toString()
        val bp = createManifest("$name · Comportamiento", description, "data", bpHeader)
        bp.put("dependencies", JSONArray().put(JSONObject().apply {
            put("uuid", rpHeader)
            put("version", JSONArray().put(1).put(0).put(0))
        }))
        val rp = createManifest("$name · Recursos", description, "resources", rpHeader)
        val safeName = name.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "CodeMasterAddon" }
        pendingAddonEntries = linkedMapOf(
            "$safeName_BP/manifest.json" to bp.toString(2).toByteArray(Charsets.UTF_8),
            "$safeName_RP/manifest.json" to rp.toString(2).toByteArray(Charsets.UTF_8),
            "$safeName_RP/README.txt" to "Paquete de recursos de CodeMaster. Agrega texturas en textures/ y geometrías en models/entity/.".toByteArray(Charsets.UTF_8),
            "$safeName_BP/README.txt" to "Paquete de comportamiento de CodeMaster. Agrega definiciones en blocks/, entities/ y otros directorios compatibles.".toByteArray(Charsets.UTF_8)
        )
        generatedGeometryJson?.let { geometry ->
            val fileName = geometryIdentifierInput.text.toString()
                .replace(Regex("[^A-Za-z0-9_.-]"), "_")
            pendingAddonEntries["$safeName_RP/models/entity/$fileName.geo.json"] = geometry.toByteArray(Charsets.UTF_8)
        }
        importedTextureBytes?.let { imageBytes ->
            val fileName = importedTextureName.ifBlank { "codemaster_texture.png" }
                .replace(Regex("[^A-Za-z0-9_.-]"), "_")
            pendingAddonEntries["$safeName_RP/textures/entity/$fileName"] = imageBytes
        }
        createAddonFile.launch("${safeName}.mcaddon")
    }

    private var pendingManifestBytes: ByteArray = byteArrayOf()
    private var pendingPackFileName: String = "Addon.mcpack"
    private val createPackFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { output ->
                    ZipOutputStream(output).use { zip ->
                        zip.putNextEntry(java.util.zip.ZipEntry("manifest.json"))
                        zip.write(pendingManifestBytes)
                        zip.closeEntry()
                        if (packTypeSpinner.selectedItemPosition == 1) {
                            generatedGeometryJson?.let { geometry ->
                                val fileName = geometryIdentifierInput.text.toString()
                                    .replace(Regex("[^A-Za-z0-9_.-]"), "_")
                                zip.putNextEntry(java.util.zip.ZipEntry("models/entity/$fileName.geo.json"))
                                zip.write(geometry.toByteArray(Charsets.UTF_8))
                                zip.closeEntry()
                            }
                            importedTextureBytes?.let { imageBytes ->
                                val textureName = importedTextureName.ifBlank { "codemaster_texture.png" }
                                    .replace(Regex("[^A-Za-z0-9_.-]"), "_")
                                zip.putNextEntry(java.util.zip.ZipEntry("textures/entity/$textureName"))
                                zip.write(imageBytes)
                                zip.closeEntry()
                            }
                        }
                    }
                }
                Toast.makeText(this, "Paquete .mcpack exportado", Toast.LENGTH_LONG).show()
                status.text = "Paquete exportado · manifiesto${if (packTypeSpinner.selectedItemPosition == 1 && generatedGeometryJson != null) " y geometría" else ""} incluidos"
            } catch (e: Exception) {
                Toast.makeText(this, "Error al exportar: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun storeActiveDocument() {
        val doc = openDocuments.firstOrNull { it.key == activeDocumentKey } ?: return
        if (textEditable) doc.text = editor.text.toString()
        if (doc.key == activeDocumentKey) doc.bytes = currentBytes
        doc.dirty = isDirty
    }

    private fun updateFileHeader() {
        if (!::fileName.isInitialized) return
        fileName.text = currentName.ifBlank { "Ningún archivo abierto" } + if (isDirty) "  • Cambios sin guardar" else ""
        if (::status.isInitialized && isDirty) status.text = "Cambios pendientes · pulsa Guardar para actualizar el archivo o Guardar copia para crear una copia nueva"
    }

    private fun renderTabs() {
        if (!::tabsContainer.isInitialized) return
        tabsContainer.removeAllViews()
        openDocuments.forEach { doc ->
            val tab = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val openButton = Button(this).apply {
                text = (if (doc.dirty) "● " else "") + doc.name.take(17)
                textSize = 10f
                isAllCaps = false
                setOnClickListener { activateDocument(doc) }
            }
            val closeButton = Button(this).apply {
                text = "×"; textSize = 12f; isAllCaps = false
                minWidth = dp(34)
                setOnClickListener { closeDocument(doc) }
            }
            tab.addView(openButton)
            tab.addView(closeButton)
            tabsContainer.addView(tab)
        }
    }

    private fun activateDocument(doc: EditorDocument) {
        storeActiveDocument()
        activeDocumentKey = doc.key
        currentUri = doc.uri
        currentName = doc.name
        currentMime = doc.mime
        currentBytes = doc.bytes
        textEditable = isLikelyText()
        isDirty = doc.dirty
        loadingDocument = true
        editor.isEnabled = textEditable
        editor.setText(if (textEditable) doc.text else "Este archivo es de solo vista previa. Usa Visual para inspeccionarlo o abre un archivo de texto para editar código.")
        loadingDocument = false
        previousText = editor.text.toString()
        editor.setSelection(editor.text.length)
        undoHistory.clear(); redoHistory.clear()
        fileName.text = currentName + if (isDirty) "  • Cambios sin guardar" else ""
        renderTabs()
        if (isImage()) {
            val bitmap = currentBytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
            if (bitmap != null && ::texturePreview.isInitialized) texturePreview.setImageBitmap(bitmap)
        }
        if (!textEditable) {
            refreshPreview()
            showPanel("preview")
        } else {
            showPanel("editor")
        }
        updateCursorInfo()
    }

    private fun loadDocument(uri: Uri) {
        try {
            storeActiveDocument()
            val key = uri.toString()
            val existing = openDocuments.firstOrNull { it.key == key }
            if (existing != null) {
                activateDocument(existing)
                status.text = "Pestaña recuperada · ${existing.name}"
                return
            }
            if (openDocuments.size >= 10) {
                Toast.makeText(this, "Has llegado al límite de 10 pestañas. Cierra una para abrir otra.", Toast.LENGTH_LONG).show()
                return
            }
            val name = queryDisplayName(uri) ?: (uri.lastPathSegment ?: "archivo")
            val mime = contentResolver.getType(uri) ?: ""
            val packageFile = name.endsWith(".apk", true) || name.endsWith(".mcaddon", true) || name.endsWith(".mcpack", true) || name.endsWith(".zip", true)
            val maxBytes = if (packageFile) 64 * 1024 * 1024 else 16 * 1024 * 1024
            val bytes = contentResolver.openInputStream(uri)?.use { input ->
                val out = ByteArrayOutputStream(); val buffer = ByteArray(8192); var total = 0
                while (true) {
                    val count = input.read(buffer); if (count < 0) break
                    total += count
                    if (total > maxBytes) throw IllegalArgumentException("El archivo supera el límite de ${maxBytes / (1024 * 1024)} MB de esta versión")
                    out.write(buffer, 0, count)
                }
                out.toByteArray()
            } ?: byteArrayOf()
            val isText = mime.startsWith("text/") || mime.contains("json") || name.matches(Regex("(?i).+\\.(txt|json|jsonc|js|jsx|ts|tsx|java|kt|kts|xml|html|css|py|md|yml|yaml|mcfunction|properties|toml|ini|cfg|csv|log|gradle|sh|bash|bat|lang|c|cpp|h|hpp|cs|go|rs|sql)$"))
            val doc = EditorDocument(
                key = key, uri = uri, name = name, mime = mime,
                text = if (isText) bytes.toString(Charsets.UTF_8) else "",
                bytes = bytes, dirty = false
            )
            openDocuments.add(doc)
            activateDocument(doc)
            if (isImage()) {
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                val png = name.endsWith(".png", true) || mime.equals("image/png", true)
                if (bitmap != null && png && ::textureWidthInput.isInitialized && ::textureHeightInput.isInitialized) {
                    textureWidthInput.setText(bitmap.width.toString())
                    textureHeightInput.setText(bitmap.height.toString())
                    importedTextureBytes = bytes
                    importedTextureName = name.substringAfterLast('/').ifBlank { "codemaster_texture.png" }
                    textureInfo.text = "Textura PNG lista: ${bitmap.width} × ${bitmap.height} px · $name"
                } else if (bitmap != null && ::textureInfo.isInitialized) {
                    textureInfo.text = "Imagen visualizada. Para incluirla en un paquete, importa una textura PNG."
                }
            }
            status.text = "Archivo cargado · ${(bytes.size / 1024)} KB · ${(openDocuments.size)} pestaña(s) abiertas"
            Toast.makeText(this, "Archivo abierto", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun closeDocument(doc: EditorDocument) {
        val closeAction = {
            val wasActive = activeDocumentKey == doc.key
            openDocuments.removeAll { it.key == doc.key }
            if (wasActive) {
                val next = openDocuments.lastOrNull()
                if (next != null) activateDocument(next) else clearEditorSession()
            } else renderTabs()
        }
        if (doc.dirty) {
            AlertDialog.Builder(this)
                .setTitle("Cerrar archivo con cambios")
                .setMessage("${doc.name} tiene cambios sin guardar. ¿Cerrar sin guardarlos?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Cerrar") { _, _ -> closeAction() }
                .show()
        } else closeAction()
    }

    private fun clearEditorSession() {
        activeDocumentKey = null; currentUri = null; currentName = ""; currentMime = ""; currentBytes = null
        textEditable = true; isDirty = false; editor.isEnabled = true
        loadingDocument = true; editor.setText(""); loadingDocument = false
        previousText = ""; undoHistory.clear(); redoHistory.clear()
        fileName.text = "Nuevo documento"
        renderTabs(); updateCursorInfo(); showPanel("editor")
    }

    private fun newBlankDocument() {
        storeActiveDocument()
        if (openDocuments.size >= 10) {
            Toast.makeText(this, "Cierra una pestaña antes de crear otro documento.", Toast.LENGTH_LONG).show(); return
        }
        val key = "draft:${UUID.randomUUID()}"
        val doc = EditorDocument(key, null, "sin_titulo.txt", "text/plain", "", null, true)
        openDocuments.add(doc)
        activateDocument(doc)
        status.text = "Documento nuevo · usa Guardar copia para elegir dónde crearlo"
    }

    private fun saveCurrent() {
        if (!textEditable) {
            Toast.makeText(this, "Este tipo de archivo no se puede editar como texto.", Toast.LENGTH_LONG).show(); return
        }
        val content = editor.text.toString().toByteArray(Charsets.UTF_8)
        val uri = currentUri
        if (uri == null) { pendingSaveAsBytes = content; saveCurrentAs(); return }
        try {
            val output = contentResolver.openOutputStream(uri, "wt")
                ?: throw IllegalStateException("El proveedor de archivos no permite escritura directa")
            output.use { it.write(content) }
            currentBytes = content
            isDirty = false
            storeActiveDocument()
            updateFileHeader()
            renderTabs()
            status.text = "Guardado correctamente · $currentName"
            Toast.makeText(this, "Cambios guardados", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            status.text = "No se pudo sobrescribir el original. Usa Guardar copia para exportar tus cambios."
            Toast.makeText(this, "No se pudo guardar en el original: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveCurrentAs() {
        if (!textEditable) {
            Toast.makeText(this, "Selecciona primero un archivo de texto.", Toast.LENGTH_LONG).show(); return
        }
        pendingSaveAsBytes = editor.text.toString().toByteArray(Charsets.UTF_8)
        createFile.launch(suggestedName())
    }

    private fun undoEdit() {
        if (undoHistory.isEmpty()) return
        val current = editor.text.toString()
        redoHistory.addLast(current)
        val target = undoHistory.removeLast()
        applyHistoryText(target)
    }

    private fun redoEdit() {
        if (redoHistory.isEmpty()) return
        val current = editor.text.toString()
        undoHistory.addLast(current)
        val target = redoHistory.removeLast()
        applyHistoryText(target)
    }

    private fun applyHistoryText(value: String) {
        applyingHistory = true
        editor.setText(value)
        editor.setSelection(editor.text.length)
        applyingHistory = false
        previousText = value
        isDirty = true
        storeActiveDocument()
        updateFileHeader(); renderTabs(); highlightCode(editor.text)
    }

    private fun showSearchReplaceDialog() {
        if (!textEditable) return
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        val findField = EditText(this).apply { hint = "Texto que quieres buscar"; setSingleLine(true) }
        val replaceField = EditText(this).apply { hint = "Reemplazar por (opcional)"; setSingleLine(true) }
        box.addView(findField); box.addView(replaceField)
        AlertDialog.Builder(this)
            .setTitle("Buscar y reemplazar")
            .setView(box)
            .setPositiveButton("Buscar siguiente") { _, _ -> findNext(findField.text.toString()) }
            .setNeutralButton("Reemplazar todo") { _, _ ->
                val query = findField.text.toString()
                if (query.isNotEmpty()) {
                    val replaced = editor.text.toString().replace(query, replaceField.text.toString(), ignoreCase = true)
                    editor.setText(replaced)
                    status.text = "Reemplazo completado · revisa los cambios antes de guardar"
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun findNext(query: String) {
        if (query.isBlank()) return
        val source = editor.text.toString()
        val start = editor.selectionEnd.coerceAtLeast(0).coerceAtMost(source.length)
        val found = source.indexOf(query, start, ignoreCase = true).takeIf { it >= 0 }
            ?: source.indexOf(query, 0, ignoreCase = true)
        if (found >= 0) {
            editor.requestFocus(); editor.setSelection(found, found + query.length)
            status.text = "Coincidencia encontrada en el carácter ${found + 1}"
        } else Toast.makeText(this, "No se encontró: $query", Toast.LENGTH_SHORT).show()
    }

    private fun formatCurrentJson() {
        if (!textEditable) return
        try {
            val source = editor.text.toString()
            require(source.trimStart().startsWith("{") || source.trimStart().startsWith("[")) {
                "Este archivo no parece contener un objeto o arreglo JSON."
            }
            editor.setText(prettyJson(source))
            editor.setSelection(0)
            status.text = "JSON formateado · guarda para conservar los cambios"
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo formatear: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showGoToLineDialog() {
        val input = EditText(this).apply {
            hint = "Número de línea"; inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine(true)
        }
        AlertDialog.Builder(this).setTitle("Ir a línea").setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Ir") { _, _ ->
                val requested = input.text.toString().toIntOrNull() ?: 1
                val lines = editor.text.toString().split("\n")
                val line = requested.coerceIn(1, lines.size)
                val offset = lines.take(line - 1).sumOf { it.length + 1 }.coerceAtMost(editor.text.length)
                editor.requestFocus(); editor.setSelection(offset)
            }.show()
    }

    private fun changeEditorFont(delta: Float) {
        editorFontSize = (editorFontSize + delta).coerceIn(10f, 24f)
        editor.textSize = editorFontSize
        status.text = "Tamaño del texto: ${editorFontSize.toInt()} sp"
    }

    private fun updateCursorInfo() {
        if (!::cursorInfo.isInitialized || !::editor.isInitialized) return
        val text = editor.text
        val cursor = editor.selectionStart.coerceAtLeast(0).coerceAtMost(text.length)
        val before = text.substring(0, cursor)
        val line = before.count { it == '\n' } + 1
        val column = before.length - (before.lastIndexOf('\n') + 1) + 1
        cursorInfo.text = "Línea $line · Columna $column · ${text.length} caracteres · ${openDocuments.size}/10 pestañas"
    }

    private fun showCreateFileInFolderDialog(treeUri: Uri, parentDocumentId: String) {
        val input = EditText(this).apply { hint = "ejemplo.json"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Crear archivo en esta carpeta").setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Crear") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isBlank() || name.contains("/") || name.contains("\\")) {
                    Toast.makeText(this, "Escribe un nombre de archivo válido.", Toast.LENGTH_LONG).show(); return@setPositiveButton
                }
                try {
                    val parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentDocumentId)
                    val mime = mimeForFileName(name)
                    val created = DocumentsContract.createDocument(contentResolver, parent, mime, name)
                        ?: throw IllegalStateException("Android no pudo crear el archivo")
                    loadDocument(created)
                    showPanel("editor")
                } catch (e: Exception) { Toast.makeText(this, "No se pudo crear: ${e.message}", Toast.LENGTH_LONG).show() }
            }.show()
    }

    private fun showCreateFolderDialog(treeUri: Uri, parentDocumentId: String) {
        val input = EditText(this).apply { hint = "Nueva carpeta"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Crear carpeta").setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Crear") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isBlank() || name.contains("/") || name.contains("\\")) {
                    Toast.makeText(this, "Escribe un nombre de carpeta válido.", Toast.LENGTH_LONG).show(); return@setPositiveButton
                }
                try {
                    val parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentDocumentId)
                    val created = DocumentsContract.createDocument(contentResolver, parent, DocumentsContract.Document.MIME_TYPE_DIR, name)
                        ?: throw IllegalStateException("Android no pudo crear la carpeta")
                    folderStack.add(DocumentsContract.getDocumentId(created) to name)
                    showFolderContents(treeUri)
                } catch (e: Exception) { Toast.makeText(this, "No se pudo crear: ${e.message}", Toast.LENGTH_LONG).show() }
            }.show()
    }

    private fun mimeForFileName(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "json", "jsonc" -> "application/json"
        "xml" -> "text/xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "js" -> "text/javascript"
        "html" -> "text/html"
        "css" -> "text/css"
        else -> "text/plain"
    }

    private fun refreshPreview() {
        preview.removeAllViews()
        val bytes = currentBytes
        if (bytes == null) {
            preview.addView(infoText("Abre un archivo para ver su vista previa.")); return
        }
        preview.addView(infoText("Vista visual · $currentName"))
        if (isImage()) {
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (bitmap != null) {
                preview.addView(ImageView(this).apply {
                    setImageBitmap(bitmap); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
                }, LinearLayout.LayoutParams(-1, -2))
            } else preview.addView(infoText("No se pudo decodificar la imagen."))
        } else if (currentName.endsWith(".json", true) || currentMime.contains("json")) {
            val source = editor.text.toString()
            val formatted = try { prettyJson(source) } catch (e: Exception) { "JSON no válido: ${e.message}" }
            preview.addView(infoText(formatted, true))
        } else if (currentName.endsWith(".apk", true) || currentName.endsWith(".mcaddon", true) || currentName.endsWith(".mcpack", true) || currentName.endsWith(".zip", true)) {
            preview.addView(infoText("Contenido del paquete (solo lectura de estructura):"))
            try {
                ZipInputStream(bytes.inputStream()).use { zip ->
                    var entry = zip.nextEntry; var count = 0
                    while (entry != null && count < 500) {
                        preview.addView(infoText((if (entry.isDirectory) "📁 " else "📄 ") + entry.name))
                        count++; entry = zip.nextEntry
                    }
                    if (count == 0) preview.addView(infoText("No se encontraron entradas ZIP legibles."))
                    if (count == 500) preview.addView(infoText("Lista limitada a 500 elementos."))
                }
            } catch (e: Exception) { preview.addView(infoText("No se pudo leer como ZIP: ${e.message}")) }
        } else {
            preview.addView(infoText(editor.text.toString().take(12000), true))
        }
    }

    private fun showFolderContents(treeUri: Uri) {
        folderPanel.removeAllViews()
        folderPanel.addView(infoText("Carpeta seleccionada"))
        try {
            val rootId = DocumentsContract.getTreeDocumentId(treeUri)
            if (folderStack.isEmpty()) folderStack.add(rootId to "Raíz")
            val docId = folderStack.last().first
            if (folderStack.size > 1) {
                folderPanel.addView(actionButton("← Carpeta anterior") {
                    folderStack.removeAt(folderStack.lastIndex)
                    showFolderContents(treeUri)
                })
            }
            folderPanel.addView(infoText("Ubicación: " + folderStack.joinToString(" / ") { it.second }))
            val folderActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            folderActions.addView(actionButton("Nuevo archivo aquí") { showCreateFileInFolderDialog(treeUri, docId) }, weightParams())
            folderActions.addView(actionButton("Nueva carpeta") { showCreateFolderDialog(treeUri, docId) }, weightParams())
            folderPanel.addView(folderActions)
            folderPanel.addView(actionButton("Actualizar lista") { showFolderContents(treeUri) })
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            contentResolver.query(childrenUri, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                var shown = 0
                while (cursor.moveToNext() && shown < 300) {
                    val id = cursor.getString(idCol); val name = cursor.getString(nameCol); val mime = cursor.getString(mimeCol)
                    val child = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                    folderPanel.addView(actionButton((if (mime == DocumentsContract.Document.MIME_TYPE_DIR) "📁 " else "📄 ") + name) {
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            folderStack.add(id to name)
                            showFolderContents(treeUri)
                        } else loadDocument(child)
                    })
                    shown++
                }
                if (shown == 0) folderPanel.addView(infoText("La carpeta está vacía o Android no permite listar su contenido."))
                if (shown == 300) folderPanel.addView(infoText("Vista limitada a 300 elementos."))
            }
        } catch (e: Exception) { folderPanel.addView(infoText("No se pudo listar la carpeta: ${e.message}")) }
    }

    private fun highlightCode(editable: Editable?) {
        if (editable == null) return
        val source = editable.toString()
        if (source.length > 300_000) return
        val ext = currentName.substringAfterLast('.', "").lowercase()
        val keywords = when (ext) {
            "json", "jsonc" -> listOf("true", "false", "null")
            "xml", "html" -> listOf("true", "false", "null")
            "py" -> listOf("def", "class", "import", "from", "return", "if", "else", "elif", "for", "while", "in", "True", "False", "None", "try", "except", "with", "as", "pass")
            "js", "jsx", "ts", "tsx" -> listOf("const", "let", "var", "function", "return", "if", "else", "for", "while", "class", "new", "true", "false", "null", "async", "await", "interface", "type", "export", "default", "import", "from")
            "css" -> listOf("color", "background", "display", "position", "width", "height", "margin", "padding", "border", "flex", "grid", "font-size")
            "sh", "bash" -> listOf("if", "then", "else", "fi", "for", "while", "do", "done", "case", "esac", "function", "export", "local", "return")
            "sql" -> listOf("select", "from", "where", "insert", "into", "update", "delete", "create", "table", "join", "group", "order", "by", "and", "or", "null")
            else -> listOf("package", "import", "class", "object", "fun", "val", "var", "public", "private", "protected", "static", "void", "int", "float", "double", "boolean", "return", "if", "else", "for", "while", "new", "true", "false", "null", "extends", "implements")
        }
        applyingHighlight = true
        try {
            val start = editor.selectionStart.coerceIn(0, editable.length)
            val end = editor.selectionEnd.coerceIn(0, editable.length)
            editable.getSpans(0, editable.length, ForegroundColorSpan::class.java).forEach { editable.removeSpan(it) }
            editable.getSpans(0, editable.length, StyleSpan::class.java).forEach { editable.removeSpan(it) }
            fun colorMatches(regex: Regex, color: Int, bold: Boolean = false) {
                regex.findAll(source).forEach { match ->
                    editable.setSpan(ForegroundColorSpan(color), match.range.first, match.range.last + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    if (bold) editable.setSpan(StyleSpan(Typeface.BOLD), match.range.first, match.range.last + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            colorMatches(Regex(""""([^"\\]|\\.)*"|'([^'\\]|\\.)*'"""), 0xFF16804A.toInt())
            colorMatches(Regex("//[^\n]*|#[^\n]*|/\\*[\\s\\S]*?\\*/"), 0xFF8A6D3B.toInt())
            if (keywords.isNotEmpty()) colorMatches(Regex("\\b(" + keywords.joinToString("|") { Regex.escape(it) } + ")\\b"), 0xFF245DB5.toInt(), true)
            colorMatches(Regex("\\b[0-9]+(\\.[0-9]+)?\\b"), 0xFF9A42A6.toInt())
            editor.setSelection(start, end)
        } catch (_: Exception) {
            // El resaltado nunca debe impedir la edición del archivo.
        } finally { applyingHighlight = false }
    }

    private fun saveTo(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(pendingSaveAsBytes) }
                ?: throw IllegalStateException("No se pudo abrir el destino para escritura")
            val active = openDocuments.firstOrNull { it.key == activeDocumentKey }
            if (currentUri == null && active != null) {
                active.key = uri.toString()
                active.uri = uri
                activeDocumentKey = active.key
                active.name = queryDisplayName(uri) ?: active.name
                active.mime = contentResolver.getType(uri) ?: mimeForFileName(active.name)
                active.text = pendingSaveAsBytes.toString(Charsets.UTF_8)
                active.bytes = pendingSaveAsBytes
                active.dirty = false
                currentUri = uri; currentName = active.name; currentMime = active.mime
                currentBytes = pendingSaveAsBytes; isDirty = false
                updateFileHeader(); renderTabs()
                status.text = "Nuevo archivo guardado · $currentName"
                Toast.makeText(this, "Archivo creado y guardado", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Copia exportada", Toast.LENGTH_SHORT).show()
                status.text = "Copia exportada · el archivo original se conserva; los cambios siguen pendientes en la pestaña"
            }
        } catch (e: Exception) { Toast.makeText(this, "No se pudo guardar: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun suggestedName(): String {
        val name = currentName.ifBlank { "codigo.txt" }
        val dot = name.lastIndexOf('.')
        return if (dot > 0) name.substring(0, dot) + "_editado" + name.substring(dot) else "${name}_editado.txt"
    }
    private fun isImage() = currentMime.startsWith("image/") || currentName.matches(Regex("(?i).+\\.(png|jpg|jpeg|webp|gif|bmp)"))
    private fun isLikelyText() = currentMime.startsWith("text/") || currentMime.contains("json") || currentName.matches(Regex("(?i).+\\.(txt|json|jsonc|js|jsx|ts|tsx|java|kt|kts|xml|html|css|py|md|yml|yaml|mcfunction|properties|toml|ini|cfg|csv|log|gradle|sh|bash|bat|lang|c|cpp|h|hpp|cs|go|rs|sql)"))
    private fun queryDisplayName(uri: Uri): String? = contentResolver.query(uri, arrayOf("_display_name"), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    private fun infoText(value: String, mono: Boolean = false) = TextView(this).apply {
        text = value; textSize = 13f; setTextColor(0xFF263449.toInt()); setPadding(8, 7, 8, 7)
        if (mono) typeface = Typeface.MONOSPACE
    }
    private fun prettyJson(source: String): String = try {
        when {
            source.trimStart().startsWith("{") -> JSONObject(source).toString(2)
            source.trimStart().startsWith("[") -> JSONArray(source).toString(2)
            else -> "El contenido no es un objeto o arreglo JSON."
        }
    } catch (e: Exception) { throw IllegalArgumentException(e.message ?: "sintaxis incorrecta") }

    private class CodeEditText(context: Context) : EditText(context) {
        var selectionChanged: (() -> Unit)? = null
        override fun onSelectionChanged(selStart: Int, selEnd: Int) {
            super.onSelectionChanged(selStart, selEnd)
            selectionChanged?.invoke()
        }
    }

    private class ModelPreviewView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var modelX = 1f
        private var modelY = 1f
        private var modelZ = 1f

        fun setDimensions(x: Float, y: Float, z: Float) {
            modelX = x.coerceAtLeast(0.1f)
            modelY = y.coerceAtLeast(0.1f)
            modelZ = z.coerceAtLeast(0.1f)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(0xFFE8EEF7.toInt())
            val unit = minOf(width / (modelX + modelZ + 2f), height / (modelY + (modelX + modelZ) * 0.55f + 2f)).coerceAtLeast(2f)
            val vx = modelX * unit * 0.55f
            val vz = modelZ * unit * 0.55f
            val vy = modelY * unit * 0.82f
            val cx = width * 0.5f
            val base = height * 0.78f
            val pTop = android.graphics.PointF(cx, base - vy)
            val pRight = android.graphics.PointF(cx + vx, base - vy + vx * 0.42f)
            val pBack = android.graphics.PointF(cx - vz, base - vy + vz * 0.42f)
            val pFront = android.graphics.PointF(cx + vx - vz, base - vy + (vx + vz) * 0.42f)
            val bTop = android.graphics.PointF(cx, base)
            val bRight = android.graphics.PointF(cx + vx, base + vx * 0.42f)
            val bBack = android.graphics.PointF(cx - vz, base + vz * 0.42f)
            val bFront = android.graphics.PointF(cx + vx - vz, base + (vx + vz) * 0.42f)
            fun polygon(points: List<android.graphics.PointF>, color: Int) {
                val path = Path().apply {
                    moveTo(points.first().x, points.first().y)
                    points.drop(1).forEach { lineTo(it.x, it.y) }
                    close()
                }
                paint.color = color
                paint.style = Paint.Style.FILL
                canvas.drawPath(path, paint)
                paint.color = 0xFF24354E.toInt()
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                canvas.drawPath(path, paint)
            }
            polygon(listOf(pTop, pBack, pFront, pRight), 0xFF87A9D7.toInt())
            polygon(listOf(pBack, pFront, bFront, bBack), 0xFF557BAE.toInt())
            polygon(listOf(pRight, pFront, bFront, bRight), 0xFF365D91.toInt())
            paint.style = Paint.Style.FILL
            paint.color = 0xFF263449.toInt()
            paint.textSize = 12f
            canvas.drawText("Vista isométrica · ${modelX} × ${modelY} × ${modelZ}", 12f, height - 12f, paint)
        }
    }

    // FrameLayout aislado para mantener las vistas en la misma zona de contenido.
    private class FrameLayoutCompat(context: android.content.Context) : android.widget.FrameLayout(context)
}
